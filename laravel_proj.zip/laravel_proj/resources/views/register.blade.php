<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Register</title>
        <link rel="shortcut icon" href="/favicon.png"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <script>
          window.setTimeout(function () {
              $(".alert").fadeTo(50, 0).slideUp(50, function () {
                  $(this).remove();
              });
          }, 2000);
      </script>
        <!-- Styles -->
        <style>
          #register {
                    margin-top: 10%;
                    box-shadow: 0 0 18px #ccc;
                    text-align:center;
                  }
        </style>
</head>
<body>
  <div class="col-sm-2 col-md-4 col-lg-4"></div>
<div id="register"  class="col-xs-12 col-sm-8 col-md-4 col-lg-4 span3 well well-large offset4" >
  <h2> Register </h2>

            @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif
                @if (session('err_reg'))
                        <div class="alert alert-success">
                            {{ session('err_reg') }}
                        </div>
                    @endif

    <form method="post" action="/register_a" class="form-group" enctype="multipart/form-data">
      <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
    <div class="form-group{{ $errors->has('first_name') ? ' has-error' : '' }}">
      <input class="form-control" name="first_name" type="text" placeholder="First Name" />
      <small class="text-danger">{{ $errors->first('first_name') }}</small><br>
    </div>
      <input class="form-control" name="last_name" type="text" placeholder="Last Name" /><br>
      <input class="form-control" name="contact_no" type="text" placeholder="Contact No" /><br>
    <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
      <input class="form-control" name="email" type="text" placeholder="Email" />
      <small class="text-danger">{{ $errors->first('email') }}</small><br>
    </div>
    <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
      <input class="form-control" name="password" type="password" placeholder="Password" />
      <small class="text-danger">{{ $errors->first('password') }}</small><br>
    </div>
     <div class="form-group{{ $errors->has('profile') ? ' has-error' : '' }}">
      <input name="profile" type="file"  />
      <small class="text-danger">{{ $errors->first('profile') }}</small><br>
    </div>

      <input class="btn btn-lg btn-success" type="submit" value="Register" /> <br> <br>
    </form>
<a style="float:right" href = "/login">Login</a>
</div>
  <div class="col-sm-2 col-md-4 col-lg-4"></div></body>
</html>
