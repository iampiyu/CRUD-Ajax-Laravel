<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//Route::get('insert','UserController@insertform');
//Route::post('getAllEmp','UserController@insert');
Route::get('login','UserController@loginPage');
Route::post('log_in','UserController@login_auth');
Route::get('register','UserController@registerPage');
Route::post('register_a','UserController@register_auth');
Route::post('insert','UserController@insert_emp');
Route::get('ShowEmp','UserController@ShowAllEmp');
Route::post('update_em','UserController@update_getdata');
Route::post('update','UserController@update_emp');
Route::post('delete','UserController@delete_emp');
Route::get('sendMail','UserController@sendMail');      //for mail sending
Route::get('/', function () {
    return view('welcome');
});
//Route::get('foo', function () {
//    return 'Hello World';
//});
