<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Login</title>
         <link rel="shortcut icon" href="/favicon.png"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <script>
          window.setTimeout(function () {
              $(".alert").fadeTo(50, 0).slideUp(50, function () {
                  $(this).remove();
              });
          }, 2000);
      </script>

        <!-- Styles -->
        <style>
          #login {
                    margin-top: 10%;
                    box-shadow: 0 0 18px #ccc;
                    text-align:center;
                  }
        </style>
</head>
<body>

<div class="col-sm-2 col-md-4 col-lg-4"></div>
<div id="login" class="col-xs-12 col-sm-8 col-md-4 col-lg-4 span3 well well-large offset4" >
  <h2>Account Login</h2>

    <?php if(session('error')): ?>
                  <div class="alert alert-danger">
                      <?php echo e(session('error')); ?>

                  </div>
              <?php endif; ?>
    <form method="post" action="/log_in" class="form-group">
        <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
        <input class="form-control" name="email" type="text" placeholder="Email" autofocus autocomplete />
        <small class="text-danger"><?php echo e($errors->first('email')); ?></small><br>
    </div>
    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
      <input class="form-control" name="password" type="password" placeholder="Password" />
      <small class="text-danger"><?php echo e($errors->first('password')); ?></small>
  </div>
      <label style="text-align:right" class="checkbox" for="rememberme">
        <input type="checkbox" /> Remember me
      </label>
      <input class="btn btn-md btn-success" type="submit" value="Sign In" /> <span><a  style="float:right"  href="/register">Create Account</a></span>
    </form>
</div>
<div class="col-sm-2 col-md-4 col-lg-4"></div></body>
</html>
