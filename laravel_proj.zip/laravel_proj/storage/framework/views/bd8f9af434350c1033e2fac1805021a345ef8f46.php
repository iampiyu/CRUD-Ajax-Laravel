<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Dashboard</title>
         <link rel="shortcut icon" href="/favicon.png"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/dataTable/css/jquery.dataTables.min.css">
  	<link rel="stylesheet" href="assets/dataTable/css/dataTables.bootstrap.min.css">
  	<link rel="stylesheet" href="assets/dataTable/css/fixedHeader.bootstrap.min.css">
  	<link rel="stylesheet" href="assets/dataTable/css/responsive.bootstrap.min.css">
  	<link rel="stylesheet" href="assets/dataTable/css/buttons.dataTables.min.css">
  <!-- sweetalert2 css-->
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.css">
        <script>
          window.setTimeout(function () {
              $(".alert").fadeTo(50, 0).slideUp(50, function () {
                  $(this).remove();
              });
          }, 2000);
      </script>
        <!-- Styles -->
        <style>
          #add_emp {
                    box-shadow: 0 0 18px #ccc;
                    text-align:center;
                  }
        </style>
</head>
<body>  <br><a class="btn btn-primary" style="float:right" href="/login">Log Out <img style="border-radius:50%;height:75px;width:75px" src="uploads/<?php echo e($auth_name->profile); ?>"></a><br/>
  <!-- mailContent -->

  <h1 style="text-align:center" class="text-primary"> Welcome <span class="text-danger"><?php echo e($auth_name->first_name); ?></span></h1> <br>
  <a class="btn btn-info" style="float:right" href="/sendMail">Send Mail</a>
  <?php if(session('success')): ?>
          <div class="alert alert-success">
              <?php echo e(session('success')); ?>

          </div>
      <?php endif; ?>
  <div class="container">
    <div class="col-md-4 col-lg-4"></div>
  <div id="add_emp"  class="col-xs-12 col-sm-12 col-md-4 col-lg-4 well well-large offset4" >
<form  enctype="multipart/form-data">
      <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
      <input name="emp_id" type="hidden" id="emp_id">
    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
      <input class="form-control" name="name" id="f_name" type="text" placeholder="Name" />
      <small class="text-danger"><?php echo e($errors->first('name')); ?></small><br>
    </div>
    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
      <input class="form-control" name="email" id="email" type="text" placeholder="Email" />
      <small class="text-danger"><?php echo e($errors->first('email')); ?></small><br>
    </div>
    <input class="form-control" name="address" id="address" type="text" placeholder="Address" /><br>
    <input class="form-control" name="password" type="password" id="password" placeholder="Password" /></br>

    <label style="float:left">Gender :</label>
      <input type="radio" name="gender" class="gender" id="female" value="female">Female
      <input type="radio" name="gender" class="gender" id="male" value="male">Male
    <br><br>
    <label style="float:left">Sectors :</label><span>
      <select class="form-control" style="float: right;width:70%" id="sector" name="sector">
          <option value="">select</option>
        <option value="IT">IT</option>
        <option value="H/W">H/W</option>
        <option value="S/W">S/W</option>
      </select></span><br><br>
      <div id="chkdiv">
    <label style="float:left">Web Technology :</label>  HTML <input class="web_tech" id="html" type="checkbox" name="web_tech[]" value="html" >
     CSS <input type="checkbox" class="web_tech"  name="web_tech[]" value="css" >
      MySql <input type="checkbox" class="web_tech"  name="web_tech[]" value="mysql">
     PHP <input type="checkbox" class="web_tech" name="web_tech[]" value="php" > <br><br>
</div>
     <label>Profile:</label>
     				<input type="file" name="image" id="file" value="">
     				<?php if($errors->has('image')): ?>
     	            	<span class="help-block">
     	                	<strong><?php echo e($errors->first('image')); ?></strong>
     	            	</span>
     	        	<?php endif; ?>


</form>
      <button class="btn btn-lg btn-success" id="insert">Submit</buttton>

       <button class="btn btn-lg btn-success" id="update">Update</button>
  </div>
  <div class="col-md-4 col-lg-4"></div>
</div>
<div class="container">
  <h2>All Employee List</h2>
  	<div class="table-responsive" id="sourceTbl">
  <table id="empTable" class="table table-bordered table-responsive table-striped" >
    <thead>
      <tr>
        <th>Sr. No</th>
        <th>Name</th>
        <th>Email</th>
        <th>Address</th>
        <th>Gender</th>
        <th>Sector</th>
         <th>Web Technology</th>
         <th>Action</th>
      </tr>
    </thead>
     <!-- <tbody>
      <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr id="<?php echo e($data->user_id); ?>">
      <td><?php echo e($data->name); ?></td>
      <td><?php echo e($data->email); ?></td>
      <td><?php echo e($data->address); ?></td>
      <td><?php echo e($data->gender); ?></td>
      <td><?php echo e($data->sector); ?></td>
      <td><?php echo e($data->web_tech); ?></td>
      <td><button class="btn_update">Update</button>|<button class="btn_delete">Delete</button></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody> -->
<tbody>
  <?php $number = 1; ?>
  <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr id='<?php echo e($data->user_id); ?>'>
                      <td><?php echo e($number); ?></td>
                     <td><?php echo e($data->name); ?></td>
                    <td><?php echo e($data->email); ?></td>
                    <td><?php echo e($data->address); ?></td>
                    <td><?php echo e($data->gender); ?></td>
                    <td><?php echo e($data->sector); ?></td>
                    <td><?php echo e($data->web_tech); ?></td>
                    <td><button type="button"  class="btn_update btn btn-primary">Edit</button>
                      <button type="button"  class="btn_delete btn btn-danger">Delete</button>
                </td>
                </tr>
                 <?php $number++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
    <tr>
      <th>Sr. No</th>
      <th>Name</th>
      <th>Email</th>
      <th>Address</th>
      <th>Gender</th>
      <th>Sector</th>
       <th>Web Technology</th>
       <th>Action</th>
    </tr>
  </tfoot>
  </table>
</div>
</div>
</body>
<!-- jQuery --><!-- BEGIN VENDOR JS-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<!--Start DataTable JS-->
<script src="assets/dataTable/js/jquery.dataTables.min.js"></script>
<script src="assets/dataTable/js/dataTables.bootstrap.min.js"></script>
<script src="assets/dataTable/js/dataTables.fixedHeader.min.js"></script>
<script src="assets/dataTable/js/dataTables.responsive.min.js"></script>
<script src="assets/dataTable/js/responsive.bootstrap.min.js"></script>
<script src="assets/dataTable/js/dataTables.buttons.min.js"></script>
<script src="assets/dataTable/js/buttons.flash.min.js"></script>
<script src="assets/dataTable/js/buttons.html5.min.js"></script>
<!--End DataTable JS-->
<!-- pdf JS -->
<script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<!-- Export in Excel js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>

<!-- Print page -->
 <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<!--Sweet Alert2 cdn-->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>

<script>

$(document).ready(function(){
$('#update').hide();
  //getAllRec();

  var table = $('#empTable').DataTable({
				dom: 'lBfrtip',
				buttons: ['copy', 'csv',
        {
              extend: 'excel',                                //export report in Excel
              title: "Employee list",
              exportOptions: {
                      columns: [0,1,2,3,4,5]
                  },
          },
            {
                extend: 'pdfHtml5',                           //export report in Excel
                exportOptions: {
                        columns: [0,1,2,3,4,5]
                    },
                title: "Employee list",
                orientation: 'portrate',
                pageSize: 'LEGAL',
                download: 'open'
            },
            {
                  extend: 'print',                           // for printing current page
                  exportOptions: {
                          columns: [0,1,2,3,4,5]        //display selected columns from list
                      },
                  title: "Employee list",
                  customize: function ( win ) {
                      $(win.document.body)
                          .css( 'font-size', '10pt' )
                          .prepend(
                              '<img src="uploads/favicon.png" style="position:absolute; top:0; left:0;" />'
                          );

                      $(win.document.body).find( 'table' )
                          .addClass( 'compact' )
                          .css( 'font-size', 'inherit' );
                  }
              }
            ],
				retrieve: true,
				});

			new $.fn.dataTable.Responsive( table );   //for responsive Table Layout
      //new $.fn.dataTable.FixedHeader( table );    //for FixedHeader Table Layout

function getAllRec(){
$('#empTable').DataTable({
//       paging:true,
       processing: true,
       serverSide: true,
       ajax: {"url":"/ShowEmp","dataSrc":""},

       columns: [
           { data: 'user_id'},
           { data: 'name'},
           { data: 'email'},
           { data: 'address'},
           { data: 'gender'},
           { data: 'sector' },
           { data: 'web_tech'}
         ]
   });
}
//$('#empTable').DataTable({
//  "paging":   true,
  //     "ordering": true,
  //     "info":     false
//});
/* var table = $('#empTable').DataTable({
      dom: 'lBfrtip',
      retrieve: true
      });
      new $.fn.dataTable.FixedHeader( table );
      //$(".dt-buttons").css("padding-left", "50px"); */

$('#insert').click(function(){
var name = $("#f_name").val();
var email = $("#email").val();
var address = $("#address").val();
var password = $("#password").val();
var gender = $("input[name='gender']:checked").val();
var sector = $("#sector").val();
 var web_tech1 = [];
    $('.web_tech:checked').each(function(){
      web_tech1.push($(this).val());
    });
  web_tech2 = web_tech1.join(",");

  $.ajaxSetup({
      headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
  });
var profile = $('#file').val();
//var pro2 = profile.replace("C:\fakepath\\","")
  //var profile = file.replace("C:\\fakepath\\", ""); //document.getElementById("file").files[0].name;   ,profile:profile
  //alert(pro2);

  swal({
          title: 'Are you sure?',
          text: "You want to Insert this!",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#5cb85c',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes,Insert it!'
        }).then(function () {

          $.ajax({
              url:"/insert",
             type:'post',
             data:{name:name,email:email,address:address,password:password,gender:gender,sector:sector,web_tech2:web_tech2},
             success:function(data){
      /*     var data2 = JSON.parse(data);
            var msg = data2.success_msg;
              alert(msg); */
              swal({
                                     title: JSON.parse(data).success_msg,
                                     text: 'Record Inserted Successfuly.',
                                     type: 'success'
                                 });
             location.reload();
           },
          error:function(data){
            alert(JSON.parse(data).error_msg);
//            alert("Employee insertion Failed")
          //   var data2 = JSON.parse(data);
          //   var msg1 = data2.error_msg;
          //   alert(msg1);
            location.reload();
           }
     });
   });
  });


$('#empTable').each(function() {
$(this).on('click',".btn_update", function () { //click() method triggers the click event
   var trid = $(this).closest('tr').attr('id');
//   alert(trid);
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
    $.ajax({
              url:"/update_em",
               type:'POST',
               data:{trid:trid},
               success:function(data){
              //   alert(data);
                var data1 = JSON.parse(data);
                var da = data1.result;

                  $('#f_name').val(da.name);
                  $('#emp_id').val(da.user_id);
                  $('#email').val(da.email);
                  $('#address').val(da.address);
                  $('#password').val(da.password);
                   if (da.gender == 'female'){
                     $("#female").attr('checked', 'checked');
                   }else{
                     $("#male").attr('checked', 'checked');
                   }
                  $('#sector').val(da.sector);

  /*              var webTech = da.web_tech;
                var tech_array = webTech.split(',');
                alert(tech_array);
                $.each(da.web_tech,function(index,value){
                  $('input[name="web_tech"][value=" ' + value.toString() + ' "]').prop("checked",true);
                });
*/

                var chk = da['web_tech'];
                chk = chk.split(',');                            // for sticky selected web tech
                $("#chkdiv").find('[value=' + chk.join('], [value=') + ']').prop("checked", true);

                  $('#insert').hide();
                  $('#update').show();

             },
       });
     });

     $(this).on('click',".btn_delete", function () { //click() method triggers the click event
        var trid = $(this).closest('tr').attr('id');
     //   alert(trid);
     $.ajaxSetup({
         headers: {
             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
         }
     });
     swal({
            title: 'Are you sure?',
            text: "You want to delete this!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
          }).then(function () {
         $.ajax({
                    url:"/delete",
                    method:'post',
                    data:{trid:trid},
                    success:function(data){
                  /*  var data1 = JSON.parse(data);
                   var da = data1.success;
                    alert(da); */
                    swal({
                                           title: JSON.parse(data).success,
                                           text: 'Record Deleted Successfuly.',
                                           type: 'success'
                                       });
                    $("#"+trid).closest('tr').remove();
                  },
            });
          });
      });
  });

  $('#update').click(function (){
  var e_id = $('#emp_id').val();
  var name = $("#f_name").val();
  var email = $("#email").val();
  var address = $("#address").val();
  var password = $("#password").val();
  var gender = $("input[name='gender']:checked").val();
  var sector = $("#sector").val();
   var web_tech1 = [];
      $('.web_tech:checked').each(function(){
        web_tech1.push($(this).val());
      });
    web_tech2 = web_tech1.join(",");

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
    });

    swal({
  				  title: 'Are you sure?',
  				  text: "You want to update this!",
  				  type: 'warning',
  				  showCancelButton: true,
  				  confirmButtonColor: '#5cb85c',
  				  cancelButtonColor: '#d33',
  				  confirmButtonText: 'Yes, Update it!'
  				}).then(function () {
            $.ajax({
                url:"/update",
               method:'post',
               data:{e_id:e_id,name:name,email:email,address:address,password:password,gender:gender,sector:sector,web_tech2:web_tech2},
               success:function(data){
            /*     alert(JSON.parse(data).success); */
            //  var data1 = JSON.parse(data);
              // var da = data1.success;
              // alert(da);
              swal({
                                     title: JSON.parse(data).success,
                                     text: 'Record Updated Successfuly.',
                                     timer: 1000,
                                     type: 'success'
                                 });

              location.reload();
             },
             error:function(data){
               alert(JSON.parse(data).error);
            //   var data1 = JSON.parse(data);
            //   var da = data1.error;
            //   alert(da);
                location.reload();
             }
             });
       });
    });
  //  $('#empTable').DataTable();

   });

</script>

</html>
