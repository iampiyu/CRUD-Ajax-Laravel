<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmpModel extends Model
{

      protected $table = 'tbl_users';
      protected $primarykey ='user_id';

  public function GetallEmp(){
    $result = EmpModel::select('user_id','name','email','password','address','gender','sector','web_tech')->get();
       return $result;
  }

}
