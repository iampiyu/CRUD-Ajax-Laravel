<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AuthModel extends Model
{

    protected $table = 'tbl_auth';
    protected $primarykey ='id';
    protected $fillable = ['first_name', 'last_name', 'contact_no', 'email', 'password','profile','created_at'];

/* public function showAllUsers(){
    $status = Flight::select('user_id','name','email','password','address','gender','sector','web_tech')->get();
    if($status){
    			return $status;
		}else{
    			return false;
    }; */


public function RegisterAuth($input){
   $file = $input['profile'];
   $img_name = $file->getClientOriginalName();

  $data = [
 		   'first_name'=>$input['first_name'],
 		   'last_name'=>$input['last_name'],
 		   'contact_no'=>$input['contact_no'],
       'email'=>$input['email'],
 		   'password'=>$input['password'],
       'profile' => $img_name,
       'created_at'=>date('Y-m-d h:i:s')
];
     $status = AuthModel::create($data);
 				return $status;
}

}
