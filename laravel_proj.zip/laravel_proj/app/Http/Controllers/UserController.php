<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Model;
use App\AuthModel;
use App\EmpModel;
use Illuminate\Http\File;
use Yajra\Datatables\Datatables;
use Mail;

class UserController extends Controller
{

  public function loginPage(){
    return view('login');
  }

  public function login_auth(Request $request){
    $rules = [
           'email' => 'required|email',
            'password' => 'required',
       ];
       $customMessages = [
      'required' => 'The :attribute field can not be blank.'
        ];
     $this->validate($request, $rules,$customMessages);

     $email = $request->input('email');
     $password = $request->input('password');
     $user = DB::table('tbl_auth')->select('first_name','email','password','profile')->where('email',$email)->where('password',$password)->first();
     if($user){
        $emp = DB::table('tbl_users')->select('user_id','name','email','password','address','gender','sector','web_tech')->get();
        return view('dashboard', ['employee' => $emp, 'auth_name' => $user]);
      }else
      {
          return back()->with("error", "Invalid Credentials");
      }
 }

public function ShowAllEmp(){
  $Model = new EmpModel;                          //insert data using model function
  $result = $Model->GetallEmp();
return ($result);
 //return Datatables::of(EmpModel::GetallEmp())->make(true);
}
  public function registerPage(){
      return view('register');
  }

  public function register_auth(Request $request){
    $rules = [
          'first_name' => 'required',
          'email' => 'required|email',
          'password' => 'required',
          'image' => 'mimes:jpeg,bmp,png,jpg', //only allow this type extension file.
       ];
       $this->validate($request, $rules);

       $file = $request->file('profile');
		    $file->move('uploads', $file->getClientOriginalName());   // image upload in public/upload folder.

       $inputs = $request->all();
       $UseModel = new AuthModel;                          //insert data using model function
       $result = $UseModel->RegisterAuth($inputs);
        return back()->with("success", "User Registered successfully");

  /*  $f_name = $request->input('first_name');
    $l_name = $request->input('last_name');
    $contact_no = $request->input('contact_no');
    $email = $request->input('email');
    $password = $request->input('password');
    $res = DB::table('tbl_auth')->insert(['first_name' => $f_name,'last_name' => $l_name, 'contact_no' => $contact_no,'email' => $email,'password' => $password ]);
  if($res){
    return back()->with("success", "User Registered successfully");
//    echo "You Are Registered successfully.<br/>";
  //  echo '<a href = "/login">Click Here</a> to go back.';
  }else{
      return back()->with("err_reg", " Registeration Failed");
      echo '<a href = "/login">Click Here</a> to go back.';
  } */
}

public function insert_emp(Request $request){
  $f_name = $request['name'];
  $email = $request->input('email');
  $address = $request->input('address');
  $password = $request->input('password');
  $gender = $request->input('gender');
  $sector = $request->input('sector');
  $web_tech = $request->input('web_tech2');

   $this->validate($request, [
	    	'image' => 'mimes:jpeg,bmp,png,jpg', //only allow this type extension file.
		]);

    /* $file = $request->file('profile');
    $img_name = $file->getClientOriginalName(); */

  /*  $file = $request->file('profile');
     $file->move('uploads/users', $file->getClientOriginalName());
     $file_name = $file->getClientOriginalName();*/
	//	$profile = $file->move('public/uploads', $file->getClientOriginalName());   ,'profile' => $profile

  $result = DB::table('tbl_users')->insert(['name' => $f_name,'email' => $email,'address' => $address, 'password' => $password,'gender' => $gender,'sector' => $sector,'web_tech' => $web_tech]);
  if(isset($result)){
    return json_encode(['success_msg'=>'Record Inserted Successfuly']);
// echo $profile;
  }else{
    return json_encode(['error_msg'=>'Record Could not Insert']);
  }
}

public function update_getdata(Request $request){
   $u_id =  $request->input('trid');
    $emp_data = DB::table('tbl_users')->where('user_id',$u_id)->first();
     return json_encode(['result'=>$emp_data]);
  //print_r(json_encode($emp_data));
  //return $emp_data;
}

public function update_emp(Request $request){
  $emp_id = $request->input('e_id');
  $f_name = $request->input('name');
  $email = $request->input('email');
  $address = $request->input('address');
  $password = $request->input('password');
  $gender = $request->input('gender');
  $sector = $request->input('sector');
  $web_tech = $request->input('web_tech2');
  $res = DB::table('tbl_users')->where('user_id',$emp_id)->update(['name' => $f_name,'email' => $email,'address' => $address, 'password' => $password,'gender' => $gender,'sector' => $sector,'web_tech' => $web_tech]);
  if($res){
    return json_encode(['success'=>'Record Updated Successfuly']);
  }else{
    return json_encode(['error'=>'Record Could not Update']);
  }
}

public function delete_emp(Request $request){
  $u_id =  $request->input('trid');
   $del = DB::table('tbl_users')->where('user_id',$u_id)->delete();
   if($del){
     return json_encode(['success'=>'Record Deleted Successfuly']);
   }else{
     return json_encode(['error'=>'Record Could not Deleted']);
   }
}

public function sendMail(){
  Mail::send(['text'=>'mailContent'],['name','Piyusha'],function($message){
    $message->to('sonalip.allentics@gmail.com','To Piyusha')->subject('Test Mail from Laravel project');
    $message->to('piyusha027@gmail.com','To Piyusha')->subject('Test Mail from Laravel project');
    $message->attach('/home/mayuri/Downloads/Allentics-Piyu/Installing_and_working_with__Apache_web_server.pdf');
    $message->from('piyusha.allentics@gmail.com', 'Piyusha');
  });
  echo 'Mail Sent Successfully';
}
/*
public function insertform(){
      return view('user');
   }

   public function insert(Request $request){
      $name = $request->input('user_name');
      DB::insert('insert into user (name) values(?)',[$name]);
      echo "Record inserted successfully.<br/>";
      echo '<a href = "/insert">Click Here</a> to go back.';
   } */
}
